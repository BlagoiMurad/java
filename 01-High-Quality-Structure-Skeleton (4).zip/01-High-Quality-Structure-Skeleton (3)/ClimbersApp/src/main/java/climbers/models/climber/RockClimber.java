package climbers.models.climber;

public class RockClimber extends BaseClimber{
    private static final double INITTAL_STRENGTH = 120;
    public RockClimber(String name) {
        super(name, INITTAL_STRENGTH);
    }

    @Override
    void climb() {
        double newStrength = getStrength() - 60;

        // Ensure strength does not drop below zero
        if (newStrength < 0) {
            newStrength = 0;
        }

        // Set the updated strength
        setStrength(newStrength);
    }
    }

