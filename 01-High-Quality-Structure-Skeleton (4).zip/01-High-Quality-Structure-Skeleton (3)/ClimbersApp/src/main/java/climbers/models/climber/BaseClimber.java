package climbers.models.climber;

import climbers.common.ExceptionMessages;
import climbers.models.roster.Roster;

import static climbers.common.ExceptionMessages.CLIMBER_NAME_NULL_OR_EMPTY;
import static climbers.common.ExceptionMessages.CLIMBER_STRENGTH_LESS_THAN_ZERO;

public  abstract class BaseClimber {
    private String name;
    private double strength;
    private Roster roster;

    public BaseClimber(String name, double strength) {
        setName(name);
         setStrength(strength);

    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        if(name == null || name.trim().isEmpty()){
            throw new NullPointerException(ExceptionMessages.CLIMBER_NAME_NULL_OR_EMPTY);
        }
        this.name = name;
    }

    public double getStrength() {
        return strength;
    }

    protected void setStrength(double strength) {
        if(strength < 0){
            throw new IllegalArgumentException(ExceptionMessages.CLIMBER_STRENGTH_LESS_THAN_ZERO);
        }
        this.strength = strength;
    }
     boolean canClimb(){
        return strength > 0;
    }
abstract void climb();
}

