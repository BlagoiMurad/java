package climbers.models.mountain;

import java.util.Collection;

public interface Mountain {

    Collection<String> getPeaksList();

    String getName();
}
