package climbers.models.climber;

public class WallClimber extends BaseClimber {

     private static final double INITIAL_STRENGTH = 90;

    public WallClimber(String name) {
        super(name, INITIAL_STRENGTH);
    }

    @Override
    void climb() {
        double newStrength = getStrength() - 30;

        // Ensure strength does not drop below zero
        if (newStrength < 0) {
            newStrength = 0;
        }

        // Set the updated strength
        setStrength(newStrength);
    }
}
