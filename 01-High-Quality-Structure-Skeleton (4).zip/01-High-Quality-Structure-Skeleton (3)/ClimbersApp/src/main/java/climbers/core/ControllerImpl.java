package climbers.core;

import climbers.models.climber.Climber;
import climbers.models.climber.WallClimber;
import climbers.models.mountain.Mountain;
import climbers.repositories.Repository;

public class ControllerImpl implements Controller {
    private Repository<Climber> climberRepository;
    private Repository<Mountain> mountainRepository;

    private String type;

    private String climberName;

    public ControllerImpl(Repository<Climber> climberRepository, Repository<Mountain> mountainRepository) {
        this.climberRepository = climberRepository;
        this.mountainRepository = mountainRepository;
    }


    @Override
    public String addClimber(String type, String climberName) {
        return null;
    }

    @Override
    public String addMountain(String mountainName, String... peaks) {
        return null;
    }

    @Override
    public String removeClimber(String climberName) {
        return null;
    }

    @Override
    public String startClimbing(String mountainName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
