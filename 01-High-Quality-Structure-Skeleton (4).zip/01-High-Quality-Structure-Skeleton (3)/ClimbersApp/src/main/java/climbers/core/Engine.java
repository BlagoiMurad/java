package climbers.core;

public interface Engine extends Runnable{

}
